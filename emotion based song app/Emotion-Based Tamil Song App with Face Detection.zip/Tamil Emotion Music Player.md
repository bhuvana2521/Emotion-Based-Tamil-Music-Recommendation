# Tamil Emotion Music Player

**Created by: Bhuvana Vijayakumar, B.E CSE**  
**© 2025 All Rights Reserved**

## 🎵 Project Overview

An innovative AI-powered web application that detects human facial emotions in real-time and automatically plays Tamil songs that match the detected mood. This project combines computer vision, machine learning, and music technology to create a personalized music experience.

## 🏆 Creator & Ownership

**Developer**: Bhuvana Vijayakumar  
**Qualification**: Bachelor of Engineering in Computer Science and Engineering (B.E CSE)  
**Year**: 2025  
**Project Type**: Original Creation & Intellectual Property  

> **⚠️ IMPORTANT**: This is proprietary software. All code, concepts, and implementations are the exclusive intellectual property of Bhuvana Vijayakumar, B.E CSE. Unauthorized copying, distribution, or use is strictly prohibited.

## 🚀 Features

### Core Functionality
- **Real-time Emotion Detection**: Uses face-api.js and TensorFlow.js for live facial emotion analysis
- **Automatic Music Matching**: Intelligently selects Tamil songs based on detected emotions
- **5 Emotion Categories**: Happy, Sad, Neutral, Frustrated, Vibing
- **40+ Tamil Songs**: Curated collection across all emotion categories
- **Responsive Design**: Works seamlessly on desktop and mobile devices

### Technical Features
- **AI-Powered**: Advanced machine learning for emotion recognition
- **Real-time Processing**: Live camera feed analysis with instant response
- **Modern UI/UX**: Beautiful gradient themes that change with emotions
- **Emotion History**: Tracks and displays emotion detection history
- **Auto & Manual Modes**: Both automatic cycling and manual emotion selection
- **Music Controls**: Full-featured music player with volume control

### Song Database
- **Happy Songs**: Whistle Podu, Vaathi Coming, Rowdy Baby, Maanamadurai Maamarkilaiyile, etc.
- **Sad Songs**: Po Nee Po, Yamma Yamma, Why This Kolaveri Di, Kaanum Sandhosham, etc.
- **Neutral Songs**: Oru Nathi, Saara Kaatre, Thendral Vanthu, Uyirin Uyire, etc.
- **Frustrated Songs**: Gangsta, Beast Mode, Etharkkum Thunidhavan Theme, Siriki, etc.
- **Vibing Songs**: Arabic Kuthu, Jimikki Kammal, Thalapathy Anthem, Osaka Osaka, etc.

## 🛠️ Technology Stack

### Frontend
- **React.js**: Modern JavaScript framework
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: High-quality UI components
- **Lucide Icons**: Beautiful icon library
- **Framer Motion**: Smooth animations

### AI/ML
- **face-api.js**: Face detection and emotion recognition
- **TensorFlow.js**: Machine learning in the browser
- **Computer Vision**: Real-time facial expression analysis

### Audio
- **HTML5 Audio API**: Native audio playback
- **Web Audio API**: Advanced audio processing

## 📁 Project Structure

```
emotion-music-app/
├── public/
│   ├── models/           # AI model files
│   └── index.html
├── src/
│   ├── components/
│   │   ├── EmotionDetector.jsx      # Camera-based emotion detection
│   │   ├── EmotionDetectorDemo.jsx  # Demo mode for testing
│   │   └── MusicPlayer.jsx          # Music player with song database
│   ├── App.jsx           # Main application component
│   ├── App.css          # Application styles
│   └── main.jsx         # Entry point
├── LICENSE              # Proprietary license
├── README.md           # This file
└── SONG_INTEGRATION_GUIDE.md  # Guide for adding real songs
```

## 🎯 How It Works

1. **Camera Access**: Application requests camera permission
2. **Face Detection**: AI detects and tracks facial features
3. **Emotion Analysis**: Machine learning analyzes facial expressions
4. **Music Selection**: Algorithm selects appropriate Tamil songs
5. **Automatic Playback**: Songs play automatically based on emotion
6. **Real-time Updates**: Continuous emotion monitoring and music adaptation

## 🔧 Installation & Setup

```bash
# Clone the repository (authorized users only)
git clone [repository-url]

# Navigate to project directory
cd emotion-music-app

# Install dependencies
pnpm install

# Start development server
pnpm run dev

# Build for production
pnpm run build
```

## 📱 Demo Features

Since camera access may not be available in all environments, the app includes:
- **Demo Mode**: Simulates emotion detection for testing
- **Manual Controls**: Select emotions manually to test music matching
- **Auto Cycle**: Automatically cycles through emotions every 3 seconds

## 🎨 Design Highlights

- **Emotion-based Themes**: UI colors change based on detected emotion
- **Gradient Backgrounds**: Beautiful color transitions
- **Responsive Layout**: Optimized for all screen sizes
- **Smooth Animations**: Polished user experience
- **Accessibility**: Designed with accessibility in mind

## 🔮 Future Enhancements

- **Real Song Integration**: Replace placeholder audio with actual Tamil songs
- **User Playlists**: Custom emotion-based playlists
- **Social Features**: Share favorite emotion-song combinations
- **Offline Mode**: Cache songs for offline playback
- **Advanced AI**: Improved emotion detection accuracy

## 📄 License & Legal

This software is protected under a **Proprietary License**. 

### Key Points:
- ✅ **Viewing**: Code can be viewed for educational purposes
- ✅ **Portfolio Use**: Can be showcased in academic portfolios
- ❌ **Copying**: No copying or reproduction allowed
- ❌ **Distribution**: No distribution permitted
- ❌ **Commercial Use**: No commercial use without written permission
- ❌ **Modification**: No derivative works allowed

### Legal Protection:
- All concepts and implementations are original intellectual property
- Unauthorized use will result in legal action
- Protected under copyright and intellectual property laws

## 👨‍💻 About the Creator

**Bhuvana Vijayakumar**  
Bachelor of Engineering in Computer Science and Engineering (B.E CSE)

This project demonstrates expertise in:
- Full-stack web development
- AI/ML integration
- Computer vision applications
- Modern JavaScript frameworks
- UI/UX design
- Audio processing
- Real-time applications

## 📞 Contact

For licensing inquiries, collaboration opportunities, or technical questions:
**Bhuvana Vijayakumar, B.E CSE**

---

**© 2025 Bhuvana Vijayakumar, B.E CSE. All Rights Reserved.**

*This project represents original research and development in emotion-based music recommendation systems. All code, algorithms, and concepts are proprietary intellectual property.*

